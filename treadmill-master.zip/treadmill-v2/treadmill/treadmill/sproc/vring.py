"""Treadmill vring manager."""

import signal
import sys

import logging
import yaml

import click

from treadmill import appenv
from treadmill import appcfg
from treadmill import context
from treadmill import discovery
from treadmill import logcontext as lc
from treadmill import utils
from treadmill import vring
from treadmill import zkutils


_LOGGER = logging.getLogger(__name__)


def init():
    """Top level command handler."""

    @click.command(name='vring')
    @click.option('--approot', type=click.Path(exists=True),
                  envvar='TREADMILL_APPROOT', required=True)
    @click.argument('manifest', type=click.File('rb'))
    def vring_cmd(approot, manifest):
        """Run vring manager."""
        context.GLOBAL.zk.conn.add_listener(zkutils.exit_on_disconnect)
        tm_env = appenv.AppEnvironment(approot)
        app = yaml.load(stream=manifest)

        with lc.LogContext(_LOGGER, app['name'], lc.ContainerAdapter) as log:

            # TODO(boysson): Remove all validation from here.
            utils.validate(app, [('vring', True, dict)])
            ring = app['vring']
            utils.validate(ring, [('rules', True, list), ('cells', True,
                                                          list)])

            if context.GLOBAL.cell not in ring['cells']:
                log.critical('cell %s not listed in vring.',
                             context.GLOBAL.cell)
                sys.exit(-1)

            rules = ring['rules']
            for rule in rules:
                utils.validate(rule, [('pattern', True, str),
                                      ('endpoints', True, list)])

            # Create translation for endpoint name to expected port #.
            routing = {}
            for endpoint in app.get('endpoints', []):
                routing[endpoint['name']] = {
                    'port': endpoint['port'],
                    'proto': endpoint['proto']
                }

            # Check that all ring endpoints are listed in the manifest.
            vring_endpoints = set()
            for rule in rules:
                for rule_endpoint in rule['endpoints']:
                    if rule_endpoint not in routing:
                        log.critical(
                            'vring references non-existing endpoint: [%s]',
                            rule_endpoint)
                        sys.exit(-1)
                    vring_endpoints.add(rule_endpoint)

            # TODO: discovery is limited to one rule for now.
            if len(rules) != 1:
                log.critical('(TODO): multiple rules are not supported.')
                sys.exit(-1)
            pattern = rules[0]['pattern']

            app_unique_name = appcfg.manifest_unique_name(app)

            app_discovery = discovery.Discovery(context.GLOBAL.zk.conn,
                                                pattern, '*')
            app_discovery.sync()

            # Restore default signal mask disabled by python spawning new
            # thread for Zk connection.
            #
            # TODO: should this be done as part of ZK connect?
            for sig in range(1, signal.NSIG):
                try:
                    signal.signal(sig, signal.SIG_DFL)
                except RuntimeError:
                    pass

            vring.run(
                routing,
                vring_endpoints,
                app_discovery,
                tm_env.rules,
                app['network']['vip'],
                app_unique_name,
            )

    return vring_cmd
