"""Tests for treadmill.services.*"""
