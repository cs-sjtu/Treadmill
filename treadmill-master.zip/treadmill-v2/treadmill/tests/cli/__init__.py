"""treadmill.cli tests"""
