"""Tests for treadmill.rest.*"""
