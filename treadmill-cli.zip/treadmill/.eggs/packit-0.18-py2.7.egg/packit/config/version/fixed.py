def fixed_version_generator(value, **kwargs):
    return value
