def composite_version_generator(value, **kwargs):
    return value.format(**kwargs)
