"""Treadmill modul tests."""
