"""Tests for treadmill.appcfg.*"""
