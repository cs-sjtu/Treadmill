"""Tests for treadmill.rest.api.*"""
