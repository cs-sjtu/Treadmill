"""Tests for treadmill.spawn.*."""
