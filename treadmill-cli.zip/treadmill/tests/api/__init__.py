"""Tests for treadmill.api.*"""
