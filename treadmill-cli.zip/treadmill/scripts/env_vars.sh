export TREADMILL_ZOOKEEPER=zookeeper://foo@10.10.10.10:2181
export TREADMILL_CELL=local
export TREADMILL_LDAP=ldap://10.10.10.10:1389
export TREADMILL_LDAP_SEARCH_BASE=ou=treadmill,dc=tw,dc=treadmill
