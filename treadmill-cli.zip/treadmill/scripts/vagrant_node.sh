#!/bin/bash

echo 'node provisioned!'
