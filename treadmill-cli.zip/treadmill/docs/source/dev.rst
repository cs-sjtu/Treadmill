=================================================
Treadmill Binary
=================================================

**Install PEX (Python EXecutable):**

::

   pip install git+https://github.com/thoughtworksinc/pex#egg=pex

**Build:**

::

   pex . -o treadmill -e treadmill.console:run -v
