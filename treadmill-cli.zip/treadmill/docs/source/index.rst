.. Treadmill-OSS documentation master file, created by
   sphinx-quickstart on Thu Mar 16 16:33:01 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Treadmill documentation!
=========================================

.. toctree::

   getting_started
   aws_manual
   cli_docs
   dev
   ansible

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
