Getting Started
=========================================================================

Prerequisites
^^^^^^^^^^^^^

- VirtualBox_
- Vagrant_
- Install the `Guest Additions Plugin`_ for Vagrant

::

	vagrant plugin install vagrant-vbguest

-------------------------------------------------------------------------

Setup
^^^^^^^^^^^^^

- Clone the treadmill_ repo.
- Clone the treadmill_pid1_ repo.
- Run the following commands

::

	cd treadmill
	vagrant up --provision

-------------------------------------------------------------------------

Master
^^^^^^^^^^^^^
- At this time Zookeeper and OpenLDAP should be running on 2181 and 1389 ports respectively:

::

   vagrant ssh master
   sudo su
   cd /home/centos/treadmill
   source ../env/bin/activate
   python setup.py install
   treadmill admin install --profile vagrant master --master-id 1 --run

-------------------------------------------------------------------------

Node
^^^^^^^^^^^^^^

::

   vagrant ssh node
   sudo su
   cd /home/centos/treadmill
   source ../env/bin/activate
   treadmill admin install --profile vagrant node --run

-------------------------------------------------------------------------

Schedule an App (e.g. python webserver - port 8000 )
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

::

   treadmill admin master app schedule --env prod --proid treadmld --manifest deploy/manifest.yml treadmld.foo

   treadmill admin master app schedule --env prod --proid treadmld --manifest deploy/manifest.yml treadmld.foo

-------------------------------------------------------------------------

Trace
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

::

   treadmill admin trace <appname>

-------------------------------------------------------------------------

Discovery
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

::

   treadmill admin discovery <appname> --check-state

-------------------------------------------------------------------------

SSH
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

::

   treadmill admin ssh <appname>

-------------------------------------------------------------------------


.. _VirtualBox: https://www.virtualbox.org/wiki/Downloads
.. _Vagrant: https://www.vagrantup.com/docs/installation/
.. _Guest Additions Plugin: https://github.com/dotless-de/vagrant-vbguest
.. _treadmill: https://github.com/Morgan-Stanley/treadmill
.. _treadmill_pid1: https://github.com/Morgan-Stanley/treadmill-pid1

set TREADMILL_ZOOKEEPER=zookeeper://foo@127.0.0.1:2181
python.exe -m treadmill --debug --ldap-search-base ou=treadmill,dc=tw,dc=treadmill admin master --cell local app schedule --env prod --proid treadmld --manifest treadmill/deploy/manifest.yml treadmld.foo

trace:
python.exe -m treadmill --debug admin trace --cell local treadmld.foo#0000000004

blacout server:
python.exe -m treadmill --debug admin blackout --cell local server --server desktop2 --reason test

clear blackout server:
python.exe -m treadmill --debug admin blackout --cell local server --clear --server desktop2 --reason test

list apps:
python.exe -m treadmill  admin master --cell local app list

list servers:
python.exe -m treadmill --debug admin master --cell local server list

show app state:
python.exe -m treadmill admin show --cell local --zookeeper 192.168.1.121:2181 pending
python.exe -m treadmill admin show --cell local --zookeeper 192.168.1.121:2181 scheduled
python.exe -m treadmill admin show --cell local --zookeeper 192.168.1.121:2181 running
python.exe -m treadmill admin show --cell local --zookeeper 192.168.1.121:2181 stopped

启动调度器：
treadmill sproc scheduler /home/centos/treadmill