"""Ansible playbooks init"""
