"""Treadmill main entry point."""

from . import console

console.run()
