"""Treadmill plugins reference implementations.
"""
