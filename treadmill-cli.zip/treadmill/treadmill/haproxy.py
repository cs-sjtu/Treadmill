"""
HAProxy Admin module
"""

import logging

_LOGGER = logging.getLogger(__name__)
