"""Linux direct system call interface."""
